"""
agents/approval_agent.py — Makes the final loan approval/rejection decision
"""


class ApprovalAgent:
    """
    Takes credit risk assessment + KYC result and makes the final call:
    APPROVED / REJECTED / NEED MORE DOCS
    """

    def decide(self, credit_result: dict, kyc_result: dict, customer_data: dict) -> dict:
        """
        Final decision logic.
        Returns: decision, message, conditions
        """
        kyc_passed  = kyc_result.get("kyc_passed", False)
        approved    = credit_result.get("approved", False)
        credit_score = credit_result.get("credit_score", 0)
        reasons     = credit_result.get("rejection_reasons", [])

        # ── Case 1: KYC failed ─────────────────────────
        if not kyc_passed:
            return {
                "decision": "NEED_MORE_DOCS",
                "status":   "pending_kyc",
                "message":  (
                    "⚠️  **Application On Hold — KYC Incomplete**\n\n"
                    "We couldn't verify your documents. Please:\n"
                    "   • Double-check your PAN number format (e.g., ABCDE1234F)\n"
                    "   • Ensure Aadhaar is 12 digits with no spaces\n"
                    "   • Upload clear scanned copies if available\n\n"
                    "Once verified, we'll instantly process your application!"
                ),
                "conditions": [],
            }

        # ── Case 2: Approved ───────────────────────────
        if approved:
            conditions = []

            # Premium conditions based on credit score
            if credit_score < 700:
                conditions.append("A co-applicant or guarantor may be required")
            if float(customer_data.get("loan_amount", 0)) > 1000000:
                conditions.append("Loan amount above ₹10L requires income proof submission")
            if customer_data.get("employment_type") == "self-employed":
                conditions.append("Last 2 years ITR filing required for self-employed applicants")

            name   = customer_data.get("name", "Applicant")
            amount = float(customer_data.get("loan_amount", 0))
            emi    = credit_result.get("monthly_emi", 0)
            tenure = int(customer_data.get("loan_tenure", 12))

            return {
                "decision": "APPROVED",
                "status":   "approved",
                "message": (
                    f"🎉 **CONGRATULATIONS, {name.upper()}!**\n\n"
                    f"Your loan application has been **APPROVED**! 🏆\n\n"
                    f"📋 **Approval Details:**\n"
                    f"   💰 Sanctioned Amount: ₹{amount:,.0f}\n"
                    f"   📅 Tenure:            {tenure} months\n"
                    f"   💸 Monthly EMI:       ₹{emi:,}\n"
                    f"   🏅 Credit Score:      {credit_score}\n\n"
                    f"Your sanction letter is being generated... 📄"
                ),
                "conditions": conditions,
            }

        # ── Case 3: Rejected ───────────────────────────
        tips = self._improvement_tips(credit_result, customer_data)
        return {
            "decision": "REJECTED",
            "status":   "rejected",
            "message": (
                f"😔 **We're Sorry — Application Not Approved**\n\n"
                f"After careful review, we are unable to approve your loan at this time.\n\n"
                f"**Reasons:**\n" +
                "\n".join([f"   ❌ {r}" for r in reasons]) +
                f"\n\n**💡 How to improve your chances:**\n" + tips
            ),
            "conditions": [],
        }

    def _improvement_tips(self, credit_result: dict, customer_data: dict) -> str:
        tips = []
        score = credit_result.get("credit_score", 0)
        ratio = credit_result.get("emi_income_ratio", 100)
        income = float(customer_data.get("monthly_income", 0))
        amount = float(customer_data.get("loan_amount", 0))

        if score < 650:
            tips.append("💳 Pay all existing EMIs on time to improve your credit score (takes 3–6 months)")
        if ratio > 50:
            tips.append(f"📉 Reduce loan amount below ₹{income * 30:,.0f} to keep EMI under 50% of income")
        if income < 20000:
            tips.append("💼 Add a co-applicant with higher income to boost eligibility")
        tips.append("📋 Clear any existing loan defaults before reapplying")
        tips.append("📅 You can reapply after 90 days once your profile improves")

        return "\n".join([f"   {t}" for t in tips])
