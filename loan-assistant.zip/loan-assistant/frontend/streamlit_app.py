"""
frontend/streamlit_app.py — Beautiful chat UI for the Loan Assistant
Run with: streamlit run frontend/streamlit_app.py
"""
import streamlit as st
import requests
import os
from dotenv import load_dotenv

load_dotenv()

API_URL = os.getenv("API_BASE_URL", "http://localhost:8000")

# ─────────────────────────────────────────────
#  Page Config
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="SVU Finance — AI Loan Assistant",
    page_icon="🏦",
    layout="centered",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────
#  Custom CSS
# ─────────────────────────────────────────────
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #0d47a1, #1565c0);
        color: white;
        padding: 20px 30px;
        border-radius: 12px;
        margin-bottom: 20px;
        text-align: center;
    }
    .main-header h1 { color: white; font-size: 1.8rem; margin: 0; }
    .main-header p  { color: #bbdefb; font-size: 0.95rem; margin: 5px 0 0; }

    .chat-bubble-user {
        background: #0d47a1;
        color: white;
        padding: 12px 18px;
        border-radius: 18px 18px 4px 18px;
        margin: 8px 0;
        max-width: 80%;
        margin-left: auto;
        font-size: 0.95rem;
    }
    .chat-bubble-bot {
        background: #f1f8fe;
        color: #1a1a2e;
        padding: 14px 18px;
        border-radius: 18px 18px 18px 4px;
        margin: 8px 0;
        max-width: 85%;
        border-left: 4px solid #0d47a1;
        font-size: 0.95rem;
        white-space: pre-wrap;
    }
    .stage-badge {
        background: #e3f2fd;
        color: #0d47a1;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    .stTextInput > div > div > input {
        border-radius: 25px;
        border: 2px solid #0d47a1;
        padding: 10px 20px;
    }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
#  Session State Init
# ─────────────────────────────────────────────
if "session_id"   not in st.session_state: st.session_state.session_id   = None
if "messages"     not in st.session_state: st.session_state.messages     = []
if "stage"        not in st.session_state: st.session_state.stage        = "greeting"
if "initialized"  not in st.session_state: st.session_state.initialized  = False


# ─────────────────────────────────────────────
#  Helper: Call API
# ─────────────────────────────────────────────
def send_message(user_msg: str) -> dict:
    try:
        resp = requests.post(
            f"{API_URL}/chat",
            json={
                "session_id": st.session_state.session_id,
                "message":    user_msg,
            },
            timeout=30,
        )
        if resp.status_code == 200:
            return resp.json()
        return {"reply": f"❌ Server error: {resp.status_code}", "stage": "error", "session_id": None}
    except requests.ConnectionError:
        return {
            "reply": (
                "⚠️ Cannot connect to the server.\n\n"
                f"Make sure the FastAPI server is running:\n"
                f"`uvicorn main:app --reload`\n\n"
                f"Then refresh this page."
            ),
            "stage": "error",
            "session_id": st.session_state.session_id,
        }


def get_session_status() -> dict:
    if not st.session_state.session_id:
        return {}
    try:
        resp = requests.get(f"{API_URL}/session/{st.session_state.session_id}/status", timeout=5)
        return resp.json() if resp.status_code == 200 else {}
    except Exception:
        return {}


# ─────────────────────────────────────────────
#  Sidebar
# ─────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🏦 SVU Finance")
    st.markdown("**AI Loan Assistant v1.0**")
    st.divider()

    # Stage display
    stage_labels = {
        "greeting":     "👋 Welcome",
        "product_info": "📋 Product Info",
        "collecting":   "📝 Collecting Data",
        "verification": "🔍 KYC Verification",
        "credit_check": "📊 Credit Check",
        "decision":     "⚖️ Decision",
        "letter":       "📄 Sanction Letter",
        "done":         "✅ Complete",
    }
    current_label = stage_labels.get(st.session_state.stage, st.session_state.stage)
    st.markdown(f"**Current Stage:**")
    st.markdown(f"<span class='stage-badge'>{current_label}</span>", unsafe_allow_html=True)
    st.divider()

    # Progress bar
    stages = list(stage_labels.keys())
    progress = (stages.index(st.session_state.stage) + 1) / len(stages) if st.session_state.stage in stages else 0
    st.progress(progress, text="Application Progress")
    st.divider()

    # Buttons
    if st.button("🔄 New Application", use_container_width=True):
        st.session_state.session_id  = None
        st.session_state.messages    = []
        st.session_state.stage       = "greeting"
        st.session_state.initialized = False
        st.rerun()

    # Download sanction letter
    if st.session_state.stage == "done" and st.session_state.session_id:
        st.divider()
        st.markdown("### 📄 Sanction Letter")
        try:
            r = requests.get(f"{API_URL}/download/sanction/{st.session_state.session_id}", timeout=10)
            if r.status_code == 200:
                st.download_button(
                    label="⬇️ Download PDF",
                    data=r.content,
                    file_name="sanction_letter.pdf",
                    mime="application/pdf",
                    use_container_width=True,
                )
        except Exception:
            pass

    st.divider()
    st.markdown("**Quick Tips:**")
    st.markdown("- Type naturally — AI understands you")
    st.markdown("- Answer one question at a time")
    st.markdown("- Type `help` anytime for guidance")


# ─────────────────────────────────────────────
#  Main Header
# ─────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <h1>🏦 SVU Finance — AI Loan Assistant</h1>
    <p>Swami Vivekananda University | Final Year Project | Agentic AI</p>
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
#  Initialize: Send first message automatically
# ─────────────────────────────────────────────
if not st.session_state.initialized:
    result = send_message("hello")
    if result:
        st.session_state.session_id  = result.get("session_id")
        st.session_state.stage       = result.get("stage", "greeting")
        st.session_state.messages.append({"role": "assistant", "content": result.get("reply", "")})
        st.session_state.initialized = True


# ─────────────────────────────────────────────
#  Chat Display
# ─────────────────────────────────────────────
chat_container = st.container()
with chat_container:
    for msg in st.session_state.messages:
        if msg["role"] == "user":
            st.markdown(f'<div class="chat-bubble-user">👤 {msg["content"]}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="chat-bubble-bot">🤖 {msg["content"]}</div>', unsafe_allow_html=True)


# ─────────────────────────────────────────────
#  Input Box
# ─────────────────────────────────────────────
st.divider()
with st.form(key="chat_form", clear_on_submit=True):
    col1, col2 = st.columns([5, 1])
    with col1:
        user_input = st.text_input(
            "Your message",
            placeholder="Type your message here...",
            label_visibility="collapsed",
        )
    with col2:
        submitted = st.form_submit_button("Send ➤", use_container_width=True)

    if submitted and user_input.strip():
        # Add user message
        st.session_state.messages.append({"role": "user", "content": user_input})

        # Call API with spinner
        with st.spinner("AI is thinking..."):
            result = send_message(user_input)

        # Add bot response
        reply = result.get("reply", "Sorry, something went wrong.")
        st.session_state.session_id = result.get("session_id", st.session_state.session_id)
        st.session_state.stage      = result.get("stage", st.session_state.stage)
        st.session_state.messages.append({"role": "assistant", "content": reply})

        st.rerun()


# ─────────────────────────────────────────────
#  Document Upload (shown during verification)
# ─────────────────────────────────────────────
if st.session_state.stage in ("verification", "collecting"):
    with st.expander("📎 Upload KYC Document (Optional - for OCR Verification)"):
        uploaded = st.file_uploader("Upload PAN / Aadhaar image", type=["png", "jpg", "jpeg"])
        if uploaded and st.session_state.session_id:
            if st.button("Verify Document"):
                with st.spinner("Running OCR verification..."):
                    files = {"file": (uploaded.name, uploaded.getvalue(), uploaded.type)}
                    resp  = requests.post(
                        f"{API_URL}/upload/document/{st.session_state.session_id}",
                        files=files, timeout=30,
                    )
                    if resp.status_code == 200:
                        result = resp.json()
                        kyc    = result.get("kyc_result", {})
                        if kyc.get("kyc_passed"):
                            st.success("✅ Document verified successfully!")
                        else:
                            st.error(f"❌ Verification failed: {kyc.get('message')}")
                    else:
                        st.error("Upload failed. Please try again.")
