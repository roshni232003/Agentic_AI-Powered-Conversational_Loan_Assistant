"""
ml/train_model.py — Train & save the XGBoost credit risk model
Run this ONCE before starting the app: python ml/train_model.py
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import LabelEncoder
import xgboost as xgb
import joblib
import os

# ─────────────────────────────────────────────
#  1. Generate mock training data
# ─────────────────────────────────────────────
np.random.seed(42)
n = 5000

data = pd.DataFrame({
    "monthly_income":    np.random.randint(15000, 200000, n),
    "loan_amount":       np.random.randint(50000, 2000000, n),
    "loan_tenure":       np.random.choice([12, 24, 36, 48, 60], n),
    "age":               np.random.randint(21, 65, n),
    "existing_loans":    np.random.randint(0, 5, n),
    "employment_years":  np.random.randint(0, 30, n),
    "employment_type":   np.random.choice([0, 1], n),  # 0=salaried, 1=self-employed
    "past_defaults":     np.random.choice([0, 1], n, p=[0.85, 0.15]),
    "credit_utilization": np.random.uniform(0.1, 1.0, n),
})

# Create realistic credit score (300–900)
data["credit_score"] = (
    900
    - data["past_defaults"]      * 200
    - data["existing_loans"]     * 30
    - data["credit_utilization"] * 100
    + data["employment_years"]   * 5
    + (data["monthly_income"] / 10000) * 10
).clip(300, 900).astype(int)

# Target: approved (1) or rejected (0)
data["approved"] = (
    (data["credit_score"] >= 650) &
    (data["past_defaults"] == 0) &
    (data["loan_amount"] <= data["monthly_income"] * 50) &
    (data["monthly_income"] >= 20000)
).astype(int)

print(f"📊 Dataset: {n} samples | Approved: {data['approved'].sum()} | Rejected: {n - data['approved'].sum()}")

# ─────────────────────────────────────────────
#  2. Train / Test split
# ─────────────────────────────────────────────
features = [
    "monthly_income", "loan_amount", "loan_tenure", "age",
    "existing_loans", "employment_years", "employment_type",
    "past_defaults", "credit_utilization", "credit_score"
]

X = data[features]
y = data["approved"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ─────────────────────────────────────────────
#  3. Train XGBoost
# ─────────────────────────────────────────────
model = xgb.XGBClassifier(
    n_estimators=200,
    max_depth=6,
    learning_rate=0.1,
    use_label_encoder=False,
    eval_metric="logloss",
    random_state=42
)
model.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)

# ─────────────────────────────────────────────
#  4. Evaluate
# ─────────────────────────────────────────────
y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f"\n✅ Model Accuracy: {acc:.2%}")
print("\n📋 Classification Report:")
print(classification_report(y_test, y_pred, target_names=["Rejected", "Approved"]))

# ─────────────────────────────────────────────
#  5. Save model & feature names
# ─────────────────────────────────────────────
os.makedirs("ml", exist_ok=True)
joblib.dump(model,    "ml/credit_model.pkl")
joblib.dump(features, "ml/feature_names.pkl")
print("\n💾 Model saved to ml/credit_model.pkl")
print("💾 Features saved to ml/feature_names.pkl")
