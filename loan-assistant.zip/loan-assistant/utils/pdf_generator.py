"""
utils/pdf_generator.py — Generates the official PDF Sanction Letter
"""
from fpdf import FPDF
from datetime import datetime, timedelta
import os
import random
import string


def _random_ref() -> str:
    """Generate a random application reference number."""
    chars = string.ascii_uppercase + string.digits
    return "SVU/LOAN/" + "".join(random.choices(chars, k=10))


class SanctionLetterPDF(FPDF):
    def header(self):
        # Bank logo / header bar
        self.set_fill_color(13, 71, 161)          # Deep blue
        self.rect(0, 0, 210, 30, "F")

        self.set_font("Helvetica", "B", 18)
        self.set_text_color(255, 255, 255)
        self.set_xy(10, 8)
        self.cell(0, 10, "SVU FINANCE — LOAN SANCTION LETTER", align="C")
        self.ln(25)

    def footer(self):
        self.set_y(-20)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(100, 100, 100)
        self.cell(0, 10, f"Page {self.page_no()} | Swami Vivekananda University Finance Division | Confidential", align="C")


def generate_sanction_letter(
    customer_name: str,
    loan_amount: float,
    loan_tenure: int,
    monthly_income: float,
    credit_score: int,
    purpose: str,
    output_dir: str = "sanction_letters"
) -> str:
    """
    Generate a professional loan sanction letter PDF.
    Returns the file path of the saved PDF.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Compute EMI (simple formula)
    annual_rate = 0.115 if credit_score >= 750 else 0.135
    monthly_rate = annual_rate / 12
    emi = loan_amount * monthly_rate * (1 + monthly_rate) ** loan_tenure / \
          ((1 + monthly_rate) ** loan_tenure - 1)

    ref_number  = _random_ref()
    today       = datetime.today()
    expiry_date = today + timedelta(days=30)
    interest_rate = annual_rate * 100

    pdf = SanctionLetterPDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=20)

    # ── Reference & Date ────────────────────
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(60, 60, 60)
    pdf.cell(0, 6, f"Ref No: {ref_number}", ln=True)
    pdf.cell(0, 6, f"Date: {today.strftime('%d %B %Y')}", ln=True)
    pdf.ln(5)

    # ── Addressee ────────────────────────────
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(13, 71, 161)
    pdf.cell(0, 8, "TO,", ln=True)
    pdf.set_text_color(30, 30, 30)
    pdf.set_font("Helvetica", "", 11)
    pdf.cell(0, 7, f"Mr./Ms. {customer_name.upper()}", ln=True)
    pdf.ln(4)

    # ── Subject line ─────────────────────────
    pdf.set_fill_color(227, 242, 253)
    pdf.set_font("Helvetica", "B", 11)
    pdf.set_text_color(13, 71, 161)
    pdf.cell(0, 10, f"  Subject: Sanction of Personal Loan — ₹{loan_amount:,.0f}", ln=True, fill=True)
    pdf.ln(5)

    # ── Body ─────────────────────────────────
    pdf.set_text_color(40, 40, 40)
    pdf.set_font("Helvetica", "", 11)
    pdf.multi_cell(0, 7,
        f"Dear {customer_name},\n\n"
        f"We are pleased to inform you that your application for a Personal Loan has been reviewed "
        f"and APPROVED by our credit committee. Based on your financial profile and credit assessment, "
        f"the following loan has been sanctioned in your favour:"
    )
    pdf.ln(5)

    # ── Loan Details Table ────────────────────
    pdf.set_font("Helvetica", "B", 11)
    pdf.set_fill_color(13, 71, 161)
    pdf.set_text_color(255, 255, 255)
    pdf.cell(95, 9, "  LOAN DETAILS", border=0, fill=True)
    pdf.cell(95, 9, "  AMOUNT / TERMS", border=0, fill=True, ln=True)

    rows = [
        ("Sanctioned Loan Amount",  f"₹ {loan_amount:,.2f}"),
        ("Loan Tenure",             f"{loan_tenure} Months"),
        ("Annual Interest Rate",    f"{interest_rate:.1f}% p.a. (Reducing Balance)"),
        ("Monthly EMI",             f"₹ {emi:,.2f}"),
        ("Loan Purpose",            purpose),
        ("Processing Fee",          f"₹ {loan_amount * 0.01:,.2f} (1% of loan amount)"),
        ("Credit Score",            str(credit_score)),
        ("Offer Valid Until",       expiry_date.strftime("%d %B %Y")),
    ]

    pdf.set_font("Helvetica", "", 10)
    for i, (label, value) in enumerate(rows):
        fill = i % 2 == 0
        pdf.set_fill_color(232, 240, 253) if fill else pdf.set_fill_color(255, 255, 255)
        pdf.set_text_color(40, 40, 40)
        pdf.cell(95, 9, f"  {label}", border=1, fill=fill)
        pdf.cell(95, 9, f"  {value}", border=1, fill=fill, ln=True)

    pdf.ln(8)

    # ── Terms & Conditions ────────────────────
    pdf.set_font("Helvetica", "B", 11)
    pdf.set_text_color(13, 71, 161)
    pdf.cell(0, 8, "Terms & Conditions:", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(40, 40, 40)
    terms = [
        "1. This sanction is valid for 30 days from the date of issue.",
        "2. Disbursement is subject to successful KYC and document verification.",
        "3. Any false declaration will lead to immediate loan cancellation.",
        "4. Prepayment allowed after 6 EMIs with 2% foreclosure charge.",
        "5. EMI auto-debit will be set up via NACH mandate.",
        "6. Interest rate is subject to change per RBI guidelines.",
    ]
    for term in terms:
        pdf.cell(0, 6, term, ln=True)

    pdf.ln(8)

    # ── Signature ────────────────────────────
    pdf.set_font("Helvetica", "B", 11)
    pdf.set_text_color(13, 71, 161)
    pdf.cell(0, 7, "Authorised Signatory", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(40, 40, 40)
    pdf.cell(0, 6, "Ms. Sangita Bose", ln=True)
    pdf.cell(0, 6, "Head — Credit & Loan Operations", ln=True)
    pdf.cell(0, 6, "SVU Finance, Swami Vivekananda University", ln=True)

    # ── Congratulations banner ───────────────
    pdf.ln(10)
    pdf.set_fill_color(232, 245, 233)
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(27, 94, 32)
    pdf.cell(0, 12, "🎉  Congratulations! Your loan journey starts here.", ln=True, fill=True, align="C")

    # Save
    filename = f"sanction_{customer_name.replace(' ', '_')}_{today.strftime('%Y%m%d')}.pdf"
    filepath = os.path.join(output_dir, filename)
    pdf.output(filepath)

    return filepath
